# Traverse DXVK frame wait update

Base: Gcenx/DXVK-macOS v1.10.3-20230507-repack, commit 8f1e28deed3ad30802f7e1bdff428ec14e6e7817.

Upstream source: https://github.com/Gcenx/DXVK-macOS/archive/8f1e28deed3ad30802f7e1bdff428ec14e6e7817.tar.gz

Apply dxvk-v1.10.3-wine-frame-wait.patch to this exact source. The upstream tree already includes async shader compilation. Build x64 and x32 with build-dxvk-local.sh; toolchain versions and options are in build-record.json.

The update uses NtDelayExecution for the whole idle interval on Wine, retaining delay compensation and the native Windows fallback. Only d3d11.dll is rebuilt for deployment. Both d3d10core.dll payloads are retained byte for byte from the original native macOS release.

limiter-mechanism-test contains the real limiter source, deterministic platform stubs, and test records. It verifies timer selection and compensation, rather than actual graphics timing or power consumption.

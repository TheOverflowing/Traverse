# Window visibility policy

The hidden-window cap applies only when IsIconic returns true or IsWindowVisible returns false for the swap-chain HWND. Visible windows retain their original selected limit regardless of input focus. The added blocking wait is skipped for PRESENT_TEST and PRESENT_DO_NOT_WAIT and occurs after the original device/context locks are released. Elapsed queue/presentation work counts toward the interval.

Only the two architecture-specific D3D11 DLLs change in this revision. The other payloads, prior repairs, and component licenses are retained. The source patch, complete diff, and build records are included beside this policy.

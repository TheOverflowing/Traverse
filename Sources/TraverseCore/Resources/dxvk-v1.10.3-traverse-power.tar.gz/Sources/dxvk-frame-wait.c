// SPDX-License-Identifier: MIT
#define COBJMACROS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <stdio.h>
#include <string.h>

#define WARMUP_FRAMES 8
#define MEASURED_FRAMES 120
#define GPU_TIMEOUT_MS 30000
#define PRESENT_TIMEOUT_MS 10000

static void pump_messages(void) {
    MSG message;
    while (PeekMessageW(&message, NULL, 0, 0, PM_REMOVE)) {
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }
}

static int failed(const char *operation, HRESULT hr) {
    fprintf(stderr, "%s failed: 0x%08lx\n", operation, (unsigned long)hr);
    return 0;
}

static int activate(HWND window) {
    ULONGLONG deadline = GetTickCount64() + 2000;
    ShowWindow(window, SW_SHOW);
    do {
        BringWindowToTop(window);
        SetForegroundWindow(window);
        pump_messages();
        if (GetForegroundWindow() == window) return 1;
        Sleep(10);
    } while (GetTickCount64() < deadline);
    fprintf(stderr, "Could not activate probe window\n");
    return 0;
}

static int present(HWND window, ID3D11DeviceContext *context,
                   ID3D11RenderTargetView *target, IDXGISwapChain *swapchain,
                   unsigned frame, HRESULT *last_status) {
    pump_messages();
    if (GetForegroundWindow() != window || IsIconic(window)) {
        fprintf(stderr, "Probe window lost foreground or became minimized\n");
        return 0;
    }
    const float color[4] = {(float)(frame % 60) / 60.0f, 0.2f, 0.4f, 1.0f};
    ID3D11DeviceContext_ClearRenderTargetView(context, target, color);
    *last_status = IDXGISwapChain_Present(swapchain, 0, 0);
    return *last_status == S_OK ? 1 : failed("Present", *last_status);
}

static int wait_for_gpu(ID3D11DeviceContext *context, ID3D11Query *completion) {
    BOOL complete = FALSE;
    ID3D11DeviceContext_End(context, (ID3D11Asynchronous *)completion);
    ID3D11DeviceContext_Flush(context);
    ULONGLONG deadline = GetTickCount64() + GPU_TIMEOUT_MS;
    do {
        HRESULT hr = ID3D11DeviceContext_GetData(context, (ID3D11Asynchronous *)completion,
                                                &complete, sizeof(complete),
                                                D3D11_ASYNC_GETDATA_DONOTFLUSH);
        if (FAILED(hr)) return failed("GPU event GetData", hr);
        if (hr == S_OK && complete) return 1;
        if (GetTickCount64() >= deadline) {
            fprintf(stderr, "GPU event did not complete within 30 seconds\n");
            return 0;
        }
        pump_messages();
        Sleep(1);
    } while (1);
}

int main(int argc, char **argv) {
    unsigned target_fps = 60;
    if (argc == 3 && strcmp(argv[1], "--fps") == 0) {
        if (strcmp(argv[2], "120") == 0) target_fps = 120;
        else if (strcmp(argv[2], "off") == 0) target_fps = 0;
        else if (strcmp(argv[2], "60") != 0) argc = -1;
    } else if (argc != 1) argc = -1;
    if (argc == -1) {
        fprintf(stderr, "Usage: dxvk-frame-wait.exe [--fps 60|120|off]\n");
        return 1;
    }
    char limit[16];
    snprintf(limit, sizeof(limit), "%u", target_fps);
    // Each invocation creates a fresh limiter, including an explicit disabled
    // mode that takes precedence over a game's dxvk.conf frame-rate option.
    if (!SetEnvironmentVariableA("DXVK_FRAME_RATE", limit)) {
        fprintf(stderr, "SetEnvironmentVariable failed: %lu\n", (unsigned long)GetLastError());
        return 1;
    }
    LARGE_INTEGER frequency, start = {0}, end = {0};
    if (!QueryPerformanceFrequency(&frequency) || frequency.QuadPart <= 0) {
        fprintf(stderr, "QueryPerformanceFrequency failed\n");
        return 1;
    }
    const wchar_t *class_name = L"TraverseDXVKFrameWait";
    WNDCLASSW window_class = {0};
    DXGI_SWAP_CHAIN_DESC desc = {0};
    D3D11_QUERY_DESC query_desc = {D3D11_QUERY_EVENT, 0};
    const D3D_FEATURE_LEVEL requested = D3D_FEATURE_LEVEL_11_0;
    D3D_FEATURE_LEVEL obtained;
    ID3D11Device *device = NULL;
    ID3D11DeviceContext *context = NULL;
    IDXGISwapChain *swapchain = NULL;
    ID3D11Texture2D *backbuffer = NULL;
    ID3D11RenderTargetView *target = NULL;
    ID3D11Query *completion = NULL;
    HWND window = NULL;
    HRESULT hr, last_status = E_UNEXPECTED;
    unsigned frames = 0;
    double elapsed = 0.0, rate = 0.0;
    int gpu_complete = 0;
    int result = 1;

    window_class.lpfnWndProc = DefWindowProcW;
    window_class.hInstance = GetModuleHandleW(NULL);
    window_class.lpszClassName = class_name;
    if (!RegisterClassW(&window_class)) {
        fprintf(stderr, "RegisterClass failed: %lu\n", (unsigned long)GetLastError());
        return 1;
    }
    window = CreateWindowW(class_name, L"Traverse DXVK frame wait probe", WS_OVERLAPPEDWINDOW,
                           100, 100, 400, 300, NULL, NULL, window_class.hInstance, NULL);
    if (!window) {
        fprintf(stderr, "CreateWindow failed: %lu\n", (unsigned long)GetLastError());
        goto cleanup;
    }
    if (!activate(window)) goto cleanup;
    UpdateWindow(window);
    desc.BufferDesc.Width = 320;
    desc.BufferDesc.Height = 240;
    desc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    desc.SampleDesc.Count = 1;
    desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    desc.BufferCount = 1;
    desc.OutputWindow = window;
    desc.Windowed = TRUE;
    desc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    hr = D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0,
                                     &requested, 1, D3D11_SDK_VERSION, &desc,
                                     &swapchain, &device, &obtained, &context);
    if (FAILED(hr)) { failed("D3D11CreateDeviceAndSwapChain", hr); goto cleanup; }
    if (obtained != requested) { failed("Feature level 11_0", E_FAIL); goto cleanup; }
    hr = IDXGISwapChain_GetBuffer(swapchain, 0, &IID_ID3D11Texture2D, (void **)&backbuffer);
    if (FAILED(hr)) { failed("GetBuffer", hr); goto cleanup; }
    hr = ID3D11Device_CreateRenderTargetView(device, (ID3D11Resource *)backbuffer, NULL, &target);
    if (FAILED(hr)) { failed("CreateRenderTargetView", hr); goto cleanup; }
    hr = ID3D11Device_CreateQuery(device, &query_desc, &completion);
    if (FAILED(hr)) { failed("CreateQuery", hr); goto cleanup; }
    for (unsigned i = 0; i < WARMUP_FRAMES; ++i)
        if (!present(window, context, target, swapchain, i, &last_status)) goto cleanup;

    ULONGLONG deadline = GetTickCount64() + PRESENT_TIMEOUT_MS;
    QueryPerformanceCounter(&start);
    while (frames < MEASURED_FRAMES) {
        if (!present(window, context, target, swapchain, frames, &last_status)) goto cleanup;
        ++frames;
        if (GetTickCount64() >= deadline) {
            fprintf(stderr, "Present calls exceeded their 10-second timeout\n");
            goto cleanup;
        }
    }
    QueryPerformanceCounter(&end);
    elapsed = (double)(end.QuadPart - start.QuadPart) / (double)frequency.QuadPart;
    rate = elapsed > 0.0 ? (double)frames / elapsed : 0.0;
    if (target_fps) {
        // This checks limiter behavior on a small clear workload, not displayed
        // FPS. A display or Vulkan present mode may also impose a lower limit.
        if (rate < 45.0 || rate > (double)target_fps * 1.17) {
            fprintf(stderr, "Limited Present throughput %.3f is outside 45..%.2f calls/s\n",
                    rate, (double)target_fps * 1.17);
            goto cleanup;
        }
    }
    if (!wait_for_gpu(context, completion)) goto cleanup;
    gpu_complete = 1;
    result = 0;

cleanup:
    if (context) ID3D11DeviceContext_ClearState(context);
    if (completion) ID3D11Query_Release(completion);
    if (target) ID3D11RenderTargetView_Release(target);
    if (backbuffer) ID3D11Texture2D_Release(backbuffer);
    if (swapchain) IDXGISwapChain_Release(swapchain);
    if (context) ID3D11DeviceContext_Release(context);
    if (device) ID3D11Device_Release(device);
    if (window) DestroyWindow(window);
    UnregisterClassW(class_name, window_class.hInstance);
    printf("{\"test\":\"dxvk-frame-wait\",\"target_fps\":%u,"
           "\"warmup_frames\":%u,\"present_calls\":%u,\"seconds\":%.6f,"
           "\"calls_per_second\":%.3f,\"last_status\":\"0x%08lx\","
           "\"gpu_event_complete\":%s,\"passed\":%s}\n",
           target_fps, WARMUP_FRAMES, frames, elapsed, rate, (unsigned long)last_status,
           gpu_complete ? "true" : "false", result == 0 ? "true" : "false");
    return result;
}

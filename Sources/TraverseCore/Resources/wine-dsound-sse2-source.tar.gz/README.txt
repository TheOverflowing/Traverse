Traverse DirectSound SSE2 build

The Wine 11 DirectSound source is unchanged. The build selects SSE2 arithmetic for the 32-bit mixer to avoid x87 emulation overhead on Rosetta. This package includes the module, Wine headers, SDK headers, the linked SDK WineCRT0 source, LGPL licenses, and the build script. Rebuild with the retained complete Wine source and the Wine 8.17 SDK using scripts/build-dsound-local.sh. The script retains COM registration and version resources and marks the output as a Wine builtin.

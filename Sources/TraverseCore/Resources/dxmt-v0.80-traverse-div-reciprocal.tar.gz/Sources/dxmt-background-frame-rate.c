// SPDX-License-Identifier: MIT
// Run with DXMT_CONFIG=d3d11.preferredMaxFrameRate=60;d3d11.backgroundMaxFrameRate=30.
#define COBJMACROS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <float.h>
#include <stdio.h>
#include <string.h>

#define PHASE_SECONDS 2.0
#define PHASE_TIMEOUT_MS 10000
#define GPU_TIMEOUT_MS 30000
#define WARMUP_FRAMES 8

static LARGE_INTEGER frequency;

static double now_seconds(void) {
    LARGE_INTEGER value;
    QueryPerformanceCounter(&value);
    return (double)value.QuadPart / (double)frequency.QuadPart;
}

static void pump_messages(void) {
    MSG message;
    while (PeekMessageW(&message, NULL, 0, 0, PM_REMOVE)) {
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }
}

static int failed(const char *operation, HRESULT hr) {
    fprintf(stderr, "%s failed: 0x%08lx\n", operation, (unsigned long)hr);
    return 0;
}

static int check_window_state(HWND game, HWND foreground, int minimized, int visible) {
    if ((!minimized && visible && GetForegroundWindow() != foreground) ||
        !!IsIconic(game) != minimized ||
        !!IsWindowVisible(game) != visible) {
        fprintf(stderr, "Window state changed: foreground=%p expected=%p minimized=%d expected=%d visible=%d expected=%d\n",
                (void *)GetForegroundWindow(), (void *)foreground,
                !!IsIconic(game), minimized, !!IsWindowVisible(game), visible);
        return 0;
    }
    return 1;
}

static int activate(HWND window) {
    ULONGLONG deadline = GetTickCount64() + 2000;
    ShowWindow(window, SW_SHOW);
    do {
        BringWindowToTop(window);
        SetForegroundWindow(window);
        SetFocus(window);
        pump_messages();
        if (GetForegroundWindow() == window) return 1;
        Sleep(10);
    } while (GetTickCount64() < deadline);
    fprintf(stderr, "Could not activate probe window: foreground=%p expected=%p\n",
            (void *)GetForegroundWindow(), (void *)window);
    return 0;
}

static int present(ID3D11DeviceContext *context, ID3D11RenderTargetView *target,
                   IDXGISwapChain *swapchain, UINT flags, HRESULT expected,
                   int allow_occluded, unsigned frame, HRESULT *observed) {
    if (!(flags & DXGI_PRESENT_TEST)) {
        const float color[4] = {(float)(frame % 60) / 60.0f, 0.25f, 0.5f, 1.0f};
        ID3D11DeviceContext_ClearRenderTargetView(context, target, color);
    }
    HRESULT hr = IDXGISwapChain_Present(swapchain, 0, flags);
    *observed = hr;
    return hr == expected || (allow_occluded && hr == DXGI_STATUS_OCCLUDED)
        ? 1 : failed("Present", hr);
}

static int cadence_phase(const char *name, ID3D11DeviceContext *context,
                         ID3D11RenderTargetView *target, IDXGISwapChain *swapchain,
                         HWND game, HWND foreground, int minimized, int visible,
                         HRESULT expected, int allow_occluded, double minimum, double maximum) {
    unsigned frames = 0;
    int valid = 1;
    HRESULT observed = E_UNEXPECTED;
    for (unsigned i = 0; i < WARMUP_FRAMES; ++i) {
        pump_messages();
        if (!check_window_state(game, foreground, minimized, visible) ||
            !present(context, target, swapchain, 0, expected, allow_occluded, i, &observed)) return 0;
    }
    double start = now_seconds();
    ULONGLONG deadline = GetTickCount64() + PHASE_TIMEOUT_MS;
    do {
        pump_messages();
        if (!check_window_state(game, foreground, minimized, visible) ||
            !present(context, target, swapchain, 0, expected, allow_occluded, frames, &observed)) {
            valid = 0;
            break;
        }
        ++frames;
        if (GetTickCount64() >= deadline) {
            fprintf(stderr, "%s exceeded its 10-second timeout\n", name);
            valid = 0;
            break;
        }
    } while (now_seconds() - start < PHASE_SECONDS);
    double elapsed = now_seconds() - start;
    double rate = elapsed > 0.0 ? (double)frames / elapsed : 0.0;
    if (valid && rate < minimum) {
        fprintf(stderr, "%s cadence %.3f is below %.1f calls/s\n", name, rate, minimum);
        valid = 0;
    } else if (valid && rate > maximum) {
        fprintf(stderr, "%s cadence %.3f exceeds %.1f calls/s\n", name, rate, maximum);
        valid = 0;
    }
    printf("{\"type\":\"phase\",\"phase\":\"%s\",\"present_calls\":%u,"
           "\"seconds\":%.6f,\"calls_per_second\":%.3f,\"present_flags\":0,"
           "\"expected_status\":\"0x%08lx\",\"last_status\":\"0x%08lx\","
           "\"occluded_status_allowed\":%s,\"minimized\":%s,\"visible\":%s,\"passed\":%s}\n",
           name, frames, elapsed, rate, (unsigned long)expected, (unsigned long)observed,
           allow_occluded ? "true" : "false", minimized ? "true" : "false",
           visible ? "true" : "false", valid ? "true" : "false");
    fflush(stdout);
    return valid;
}

static int flags_phase(const char *name, ID3D11DeviceContext *context,
                       ID3D11RenderTargetView *target, IDXGISwapChain *swapchain,
                       HWND game, HWND foreground, UINT flags, HRESULT expected,
                       unsigned calls, int assert_no_wait) {
    unsigned completed = 0;
    int valid = 1;
    HRESULT observed = E_UNEXPECTED;
    double start = now_seconds();
    ULONGLONG deadline = GetTickCount64() + PHASE_TIMEOUT_MS;
    for (unsigned i = 0; i < calls; ++i) {
        pump_messages();
        if (!check_window_state(game, foreground, 1, 1) ||
            !present(context, target, swapchain, flags, expected, 0, i, &observed)) {
            valid = 0;
            break;
        }
        ++completed;
        if (GetTickCount64() >= deadline) {
            fprintf(stderr, "%s exceeded its 10-second timeout\n", name);
            valid = 0;
            break;
        }
    }
    double elapsed = now_seconds() - start;
    // Only TEST and the blit occlusion path already return before display waits.
    // Flip DO_NOT_WAIT retains DXMT's existing queue and drawable behavior.
    if (valid && assert_no_wait && elapsed > 0.3) {
        fprintf(stderr, "%s took %.6f seconds; the occlusion limiter must not wait for these flags\n",
                name, elapsed);
        valid = 0;
    }
    printf("{\"type\":\"flags\",\"phase\":\"%s\",\"present_calls\":%u,"
           "\"seconds\":%.6f,\"present_flags\":%u,\"expected_status\":\"0x%08lx\","
           "\"last_status\":\"0x%08lx\",\"no_wait_asserted\":%s,\"passed\":%s}\n",
           name, completed, elapsed, flags, (unsigned long)expected, (unsigned long)observed,
           assert_no_wait ? "true" : "false", valid ? "true" : "false");
    fflush(stdout);
    return valid;
}

static int wait_for_gpu(ID3D11DeviceContext *context, ID3D11Query *completion) {
    BOOL complete = FALSE;
    ID3D11DeviceContext_End(context, (ID3D11Asynchronous *)completion);
    ID3D11DeviceContext_Flush(context);
    ULONGLONG deadline = GetTickCount64() + GPU_TIMEOUT_MS;
    do {
        HRESULT hr = ID3D11DeviceContext_GetData(context, (ID3D11Asynchronous *)completion,
                                                &complete, sizeof(complete),
                                                D3D11_ASYNC_GETDATA_DONOTFLUSH);
        if (FAILED(hr)) return failed("GPU event GetData", hr);
        if (hr == S_OK && complete) return 1;
        if (GetTickCount64() >= deadline) {
            fprintf(stderr, "GPU event did not complete within 30 seconds\n");
            return 0;
        }
        pump_messages();
        Sleep(1);
    } while (1);
}

int main(int argc, char **argv) {
    const int flip = argc == 2 && strcmp(argv[1], "--flip") == 0;
    if (argc > 2 || (argc == 2 && !flip)) {
        fprintf(stderr, "Usage: dxmt-background-frame-rate.exe [--flip]\n");
        return 1;
    }
    if (!QueryPerformanceFrequency(&frequency) || frequency.QuadPart <= 0) {
        fprintf(stderr, "QueryPerformanceFrequency failed\n");
        return 1;
    }
    const wchar_t *class_name = L"TraverseDXMTBackgroundFrameRate";
    WNDCLASSW window_class = {0};
    DXGI_SWAP_CHAIN_DESC desc = {0};
    D3D11_QUERY_DESC query_desc = {D3D11_QUERY_EVENT, 0};
    const D3D_FEATURE_LEVEL requested = D3D_FEATURE_LEVEL_11_0;
    D3D_FEATURE_LEVEL obtained;
    ID3D11Device *device = NULL;
    ID3D11DeviceContext *context = NULL;
    IDXGISwapChain *swapchain = NULL;
    ID3D11Texture2D *backbuffer = NULL;
    ID3D11RenderTargetView *target = NULL;
    ID3D11Query *completion = NULL;
    HWND game = NULL, other = NULL, dialog = NULL;
    HRESULT hr;
    int result = 1;
    int gpu_complete = 0;
    unsigned phases = 0;
    const HRESULT minimized_status = flip ? S_OK : DXGI_STATUS_OCCLUDED;

    window_class.lpfnWndProc = DefWindowProcW;
    window_class.hInstance = GetModuleHandleW(NULL);
    window_class.lpszClassName = class_name;
    if (!RegisterClassW(&window_class)) {
        fprintf(stderr, "RegisterClass failed: %lu\n", (unsigned long)GetLastError());
        return 1;
    }
    game = CreateWindowW(class_name, L"Traverse DXMT frame limit probe", WS_OVERLAPPEDWINDOW,
                         80, 80, 400, 300, NULL, NULL, window_class.hInstance, NULL);
    other = CreateWindowW(class_name, L"Traverse independent foreground window", WS_OVERLAPPEDWINDOW,
                          560, 80, 320, 240, NULL, NULL, window_class.hInstance, NULL);
    dialog = CreateWindowExW(WS_EX_DLGMODALFRAME, class_name, L"Traverse owned dialog",
                             WS_POPUP | WS_CAPTION | WS_SYSMENU, 120, 120, 280, 160,
                             game, NULL, window_class.hInstance, NULL);
    if (!game || !other || !dialog) {
        fprintf(stderr, "CreateWindow failed: %lu\n", (unsigned long)GetLastError());
        goto cleanup;
    }
    if (GetAncestor(game, GA_ROOTOWNER) == GetAncestor(other, GA_ROOTOWNER) ||
        GetAncestor(game, GA_ROOTOWNER) != GetAncestor(dialog, GA_ROOTOWNER)) {
        fprintf(stderr, "Probe window ownership does not match the required foreground cases\n");
        goto cleanup;
    }
    if (!activate(game)) goto cleanup;
    UpdateWindow(game);
    desc.BufferDesc.Width = 320;
    desc.BufferDesc.Height = 240;
    desc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    desc.SampleDesc.Count = 1;
    desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    desc.BufferCount = flip ? 2 : 1;
    desc.OutputWindow = game;
    desc.Windowed = TRUE;
    desc.SwapEffect = flip ? DXGI_SWAP_EFFECT_FLIP_SEQUENTIAL : DXGI_SWAP_EFFECT_DISCARD;
    hr = D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0,
                                     &requested, 1, D3D11_SDK_VERSION, &desc,
                                     &swapchain, &device, &obtained, &context);
    if (FAILED(hr)) { failed("D3D11CreateDeviceAndSwapChain", hr); goto cleanup; }
    if (obtained != requested) { failed("Feature level 11_0", E_FAIL); goto cleanup; }
    hr = IDXGISwapChain_GetBuffer(swapchain, 0, &IID_ID3D11Texture2D, (void **)&backbuffer);
    if (FAILED(hr)) { failed("GetBuffer", hr); goto cleanup; }
    hr = ID3D11Device_CreateRenderTargetView(device, (ID3D11Resource *)backbuffer, NULL, &target);
    if (FAILED(hr)) { failed("CreateRenderTargetView", hr); goto cleanup; }
    hr = ID3D11Device_CreateQuery(device, &query_desc, &completion);
    if (FAILED(hr)) { failed("CreateQuery", hr); goto cleanup; }

    // Metal's presentation cap can skip or queue presents, so API throughput
    // is not displayed FPS. The foreground lower bound checks that the
    // background CPU limiter has stopped; it does not impose a 60-call ceiling.
    if (!cadence_phase("foreground", context, target, swapchain, game, game, 0, 1,
                       S_OK, 0, 45, DBL_MAX)) goto cleanup;
    ++phases;
    if (!activate(other) ||
        !cadence_phase("visible-unfocused", context, target, swapchain, game, other, 0, 1,
                       S_OK, 0, 45, DBL_MAX)) goto cleanup;
    ++phases;
    if (!activate(dialog) ||
        !cadence_phase("owned-dialog", context, target, swapchain, game, dialog, 0, 1,
                       S_OK, 0, 45, DBL_MAX)) goto cleanup;
    ++phases;
    ShowWindow(dialog, SW_HIDE);
    ShowWindow(game, SW_MINIMIZE);
    if (!activate(other) ||
        !cadence_phase("minimized", context, target, swapchain, game, other, 1, 1,
                       minimized_status, 0, 0.0, 35)) goto cleanup;
    ++phases;
    if (!flags_phase("minimized-test", context, target, swapchain, game, other,
                     DXGI_PRESENT_TEST, minimized_status, 64, 1)) goto cleanup;
    if (!flags_phase("minimized-do-not-wait", context, target, swapchain, game, other,
                     DXGI_PRESENT_DO_NOT_WAIT, minimized_status, flip ? 24 : 64, !flip)) goto cleanup;
    ShowWindow(game, SW_RESTORE);
    if (!activate(other) ||
        !cadence_phase("restored-visible-unfocused", context, target, swapchain, game, other, 0, 1,
                       S_OK, 0, 45, DBL_MAX)) goto cleanup;
    ++phases;
    ShowWindow(game, SW_HIDE);
    if (!activate(other) ||
        !cadence_phase("hidden", context, target, swapchain, game, other, 0, 0,
                       S_OK, 1, 0.0, 35)) goto cleanup;
    ++phases;
    ShowWindow(other, SW_HIDE);
    if (!activate(game) ||
        !cadence_phase("restored-foreground", context, target, swapchain, game, game, 0, 1,
                       S_OK, 0, 45, DBL_MAX)) goto cleanup;
    ++phases;
    if (!wait_for_gpu(context, completion)) goto cleanup;
    gpu_complete = 1;
    result = 0;

cleanup:
    if (context) ID3D11DeviceContext_ClearState(context);
    if (completion) ID3D11Query_Release(completion);
    if (target) ID3D11RenderTargetView_Release(target);
    if (backbuffer) ID3D11Texture2D_Release(backbuffer);
    if (swapchain) IDXGISwapChain_Release(swapchain);
    if (context) ID3D11DeviceContext_Release(context);
    if (device) ID3D11Device_Release(device);
    if (dialog) DestroyWindow(dialog);
    if (other) DestroyWindow(other);
    if (game) DestroyWindow(game);
    UnregisterClassW(class_name, window_class.hInstance);
    printf("{\"type\":\"result\",\"test\":\"dxmt-background-frame-rate\","
           "\"swap_effect\":\"%s\",\"cadence_phases_passed\":%u,"
           "\"gpu_event_complete\":%s,\"passed\":%s}\n",
           flip ? "flip-sequential" : "discard", phases,
           gpu_complete ? "true" : "false", result == 0 ? "true" : "false");
    return result;
}

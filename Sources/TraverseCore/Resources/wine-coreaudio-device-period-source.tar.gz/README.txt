Traverse CoreAudio device-period repair

This package retains the modified driver, the headers used by the build, the Wine LGPL license, the patch, and the build record. The complete original Wine source archive is retained beside this package in the managed engine installation. Use scripts/build-coreaudio-local.sh with that extracted Wine source, the prepared Wine SDK, and the original Grapple engine. Generated headers in this package come from the listed Wine source.
